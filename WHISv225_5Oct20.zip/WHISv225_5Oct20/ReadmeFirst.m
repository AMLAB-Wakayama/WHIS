%
%  Readme First : Hearing Impairment Simulator
%  Irino, T.
%  Updated: 26 Jun 2016
%
%  Please execute HIsimFastGC_GUI.m first 
%
%  Example:
%  MATLAB>> HIsimFastGC_GUI
%  MATLAB>> HIsimFastGC
%
%  

str = ['help ' mfilename];
eval(str);
